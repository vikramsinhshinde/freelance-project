from fastapi import FastAPI
from app import models, database
from app.routers import users

models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="CloudOpsPro Backend - Day 1")

app.include_router(users.router, prefix="/users", tags=["Users"])

@app.get("/")
def root():
    return {"message": "Backend running successfully 🚀"}
