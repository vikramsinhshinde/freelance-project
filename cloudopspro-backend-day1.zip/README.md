# cloudopspro-backend (Day 1)
Simple FastAPI + PostgreSQL backend (Day 1 deliverable).

## What this contains
- FastAPI app with basic User model (CRUD)
- Dockerfile + docker-compose for local dev with Postgres
- .env example for configuration

## Quick start (on Ubuntu)
sudo apt update
sudo apt install -y docker.io docker-compose git
git clone <your-repo-url>  # or unzip this archive on your server
cd cloudopspro-backend-day1
sudo docker-compose up --build -d
curl http://localhost:8000
# Swagger docs: http://<server-ip>:8000/docs

## Notes
Replace the Docker Hub tag and push your image after testing:
  sudo docker build -t YOUR_DOCKERHUB_USERNAME/cloudopspro-backend:day1 .
  sudo docker login
  sudo docker push YOUR_DOCKERHUB_USERNAME/cloudopspro-backend:day1
